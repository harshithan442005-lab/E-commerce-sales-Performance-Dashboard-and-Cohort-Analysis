import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# =========================
# LOAD DATA
# =========================
df = pd.read_csv("data/processed_sales.csv")

st.title("📊 E-commerce Sales Dashboard")

# =========================
# KPI CARDS
# =========================
st.metric("Total Revenue", round(df["Revenue"].sum(), 2))
st.metric("Total Orders", df["OrderID"].nunique())
st.metric("Total Quantity Sold", df["Quantity"].sum())

# =========================
# SALES TREND
# =========================
st.subheader("📈 Monthly Revenue Trend")

monthly = df.groupby("OrderMonth")["Revenue"].sum()

st.line_chart(monthly)

# =========================
# COHORT ANALYSIS
# =========================
st.subheader("📊 Cohort Analysis")

cohort = pd.read_csv("data/cohort_table.csv", index_col=0)

fig, ax = plt.subplots(figsize=(10,5))
sns.heatmap(cohort, cmap="Blues", ax=ax)

st.pyplot(fig)


#top products(revenue)
st.subheader("🔥 Top 10 Products by Revenue")

top_products = df.groupby("Product")["Revenue"].sum().sort_values(ascending=False).head(10)

st.bar_chart(top_products)

#top products(quantity)
st.subheader("📦 Top Products by Quantity Sold")

top_qty = df.groupby("Product")["Quantity"].sum().sort_values(ascending=False).head(10)

st.bar_chart(top_qty)

#daily trend
st.subheader("📅 Daily Revenue Trend")

daily = df.groupby("OrderDate")["Revenue"].sum()

st.line_chart(daily)

#city sales
st.subheader("📍 Sales by City")

df["City"] = df["Address"].apply(lambda x: x.split(",")[1] if isinstance(x, str) else "Unknown")

city_sales = df.groupby("City")["Revenue"].sum()

st.bar_chart(city_sales)

st.success("Dashboard Loaded Successfully 🚀")